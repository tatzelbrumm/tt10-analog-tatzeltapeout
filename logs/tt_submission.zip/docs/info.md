<!---

This file is used to generate your project datasheet. Please fill in the information below and delete any unused
sections.

You can also include images in this folder and reference them in the markdown. Each image must be less than
512 kb in size, and the combined size of all images must be less than 1 MB.
-->

## How it works

This might not work yet ...
| Pin |
| --- |
| foo |
| bar |

## How to test

First of all, test the integration of the design into the TinyTapeout die

## External hardware

Something electrical ...
